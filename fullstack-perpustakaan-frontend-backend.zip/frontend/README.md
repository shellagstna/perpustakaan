# Frontend - Next.js + Bootstrap

## Setup
1. Install dependencies:
```
npm install
```

2. Jalankan aplikasi:
```
npm run dev
```

## Struktur Folder
- pages/books: Halaman CRUD buku
- pages/categories: Halaman CRUD kategori
- pages/users: Halaman user
- pages/loans: Halaman peminjaman