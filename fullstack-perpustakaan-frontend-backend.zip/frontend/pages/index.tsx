import Link from 'next/link';

export default function Home() {
  return (
    <div className="container mt-4">
      <h1>Perpustakaan</h1>
      <ul>
        <li><Link href="/login">Login</Link></li>
        <li><Link href="/books">Manajemen Buku</Link></li>
        <li><Link href="/categories">Manajemen Kategori</Link></li>
      </ul>
    </div>
  );
}