import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Categories() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get('http://localhost:3001/categories', {
      headers: { Authorization: `Bearer ${token}` },
    }).then(res => {
      setCategories(res.data);
    });
  }, []);

  return (
    <div className="container mt-4">
      <h2>Daftar Kategori</h2>
      <ul>
        {categories.map((cat: any) => (
          <li key={cat.id}>{cat.name}</li>
        ))}
      </ul>
    </div>
  );
}