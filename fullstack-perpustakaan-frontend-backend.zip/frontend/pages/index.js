import Head from 'next/head'
import 'bootstrap/dist/css/bootstrap.min.css'

export default function Home() {
  return (
    <div className="container mt-5">
      <Head>
        <title>Perpustakaan</title>
      </Head>
      <h1 className="text-center">Selamat Datang di Aplikasi Perpustakaan</h1>
      <p className="text-center">Gunakan menu untuk mengelola buku, kategori, peminjaman, dan pengguna.</p>
    </div>
  )
}