import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Books() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get('http://localhost:3001/books', {
      headers: { Authorization: `Bearer ${token}` },
    }).then(res => {
      setBooks(res.data);
    });
  }, []);

  return (
    <div className="container mt-4">
      <h2>Daftar Buku</h2>
      <ul>
        {books.map((book: any) => (
          <li key={book.id}>{book.title}</li>
        ))}
      </ul>
    </div>
  );
}