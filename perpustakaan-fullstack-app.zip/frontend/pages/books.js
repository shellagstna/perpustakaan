import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Books() {
  const [books, setBooks] = useState([]);
  const [form, setForm] = useState({ title: '', author: '', categoryId: '' });
  const [categories, setCategories] = useState([]);
  const [editId, setEditId] = useState(null);

  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

  const fetchBooks = async () => {
    const res = await axios.get('http://localhost:3001/books');
    setBooks(res.data);
  };

  const fetchCategories = async () => {
    const res = await axios.get('http://localhost:3001/categories');
    setCategories(res.data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const config = { headers: { Authorization: `Bearer ${token}` } };
    if (editId) {
      await axios.put('http://localhost:3001/books/' + editId, form, config);
      setEditId(null);
    } else {
      await axios.post('http://localhost:3001/books', form, config);
    }
    setForm({ title: '', author: '', categoryId: '' });
    fetchBooks();
  };

  const handleEdit = (book) => {
    setEditId(book.id);
    setForm({ title: book.title, author: book.author, categoryId: book.categoryId });
  };

  const handleDelete = async (id) => {
    const config = { headers: { Authorization: `Bearer ${token}` } };
    await axios.delete('http://localhost:3001/books/' + id, config);
    fetchBooks();
  };

  useEffect(() => {
    fetchBooks();
    fetchCategories();
  }, []);

  return (
    <div className="container mt-4">
      <h2>Manajemen Buku</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Judul" className="form-control mb-2" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required />
        <input placeholder="Penulis" className="form-control mb-2" value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} required />
        <select className="form-control mb-2" value={form.categoryId} onChange={e => setForm({ ...form, categoryId: e.target.value })} required>
          <option value="">Pilih Kategori</option>
          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>
        <button className="btn btn-success">{editId ? 'Update' : 'Tambah'}</button>
      </form>

      <hr />
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Judul</th>
            <th>Penulis</th>
            <th>Kategori</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          {books.map(book => (
            <tr key={book.id}>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.category?.name}</td>
              <td>
                <button onClick={() => handleEdit(book)} className="btn btn-warning btn-sm me-2">Edit</button>
                <button onClick={() => handleDelete(book.id)} className="btn btn-danger btn-sm">Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}