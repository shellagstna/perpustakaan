import Link from 'next/link';

export default function Home() {
  return (
    <div className="container mt-4">
      <h1>Selamat Datang di Aplikasi Perpustakaan</h1>
      <p>
        <Link href="/login" className="btn btn-primary me-2">Login</Link>
        <Link href="/books" className="btn btn-success">Lihat Buku</Link>
      </p>
    </div>
  );
}