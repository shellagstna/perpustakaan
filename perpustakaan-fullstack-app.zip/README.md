# Aplikasi Perpustakaan

Ini adalah aplikasi manajemen perpustakaan sederhana menggunakan:

- **Backend**: NestJS + Prisma + MySQL
- **Frontend**: Next.js + Bootstrap
- **Fitur**: Login, CRUD Buku, Kategori Buku, Autentikasi JWT

## Cara Menjalankan

### Backend

1. Masuk ke folder `backend`
2. Install dependensi:
   ```bash
   npm install
   ```
3. Atur koneksi database di `.env`
4. Jalankan migrasi dan seeder:
   ```bash
   npx prisma migrate dev --name init
   npx prisma db seed
   ```
5. Jalankan server:
   ```bash
   npm run start:dev
   ```

### Frontend

1. Masuk ke folder `frontend`
2. Install dependensi:
   ```bash
   npm install
   ```
3. Jalankan server:
   ```bash
   npm run dev
   ```

### Akun Login

Seeder membuat user:
- **Email**: admin@mail.com
- **Password**: 123456

## Screenshot

![ss](./public/screenshot.png)

---

Dikembangkan untuk latihan fullstack CRUD.