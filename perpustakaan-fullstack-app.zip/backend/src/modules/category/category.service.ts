import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../common/prisma.service';

@Injectable()
export class CategoryService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.category.findMany();
  }

  create(data: any) {
    return this.prisma.category.create({ data });
  }

  update(id: number, data: any) {
    return this.prisma.category.update({
      where: { id },
      data,
    });
  }

  delete(id: number) {
    return this.prisma.category.delete({ where: { id } });
  }
}