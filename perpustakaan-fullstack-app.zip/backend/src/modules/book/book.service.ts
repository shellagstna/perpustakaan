import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../common/prisma.service';

@Injectable()
export class BookService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.book.findMany({ include: { category: true } });
  }

  create(data: any) {
    return this.prisma.book.create({
      data: {
        title: data.title,
        author: data.author,
        categoryId: data.categoryId,
      },
    });
  }

  update(id: number, data: any) {
    return this.prisma.book.update({
      where: { id },
      data: {
        title: data.title,
        author: data.author,
        categoryId: data.categoryId,
      },
    });
  }

  delete(id: number) {
    return this.prisma.book.delete({ where: { id } });
  }
}