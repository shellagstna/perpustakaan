import { Module } from '@nestjs/common';
import { PrismaService } from './common/prisma.service';
import { BookModule } from './modules/book/book.module';
import { CategoryModule } from './modules/category/category.module';
import { AuthModule } from './modules/auth/auth.module';

@Module({
  imports: [BookModule, CategoryModule, AuthModule],
  providers: [PrismaService],
})
export class AppModule {}