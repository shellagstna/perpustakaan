# Perpustakaan Fullstack Project

Includes frontend and backend.