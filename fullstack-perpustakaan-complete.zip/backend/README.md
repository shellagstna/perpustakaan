# Backend - NestJS + Prisma

## Setup
1. Install dependencies:
```
npm install
```

2. Copy file .env.example ke .env dan sesuaikan `DATABASE_URL`:
```
cp .env.example .env
```

3. Generate Prisma client dan migrate schema:
```
npx prisma generate
npx prisma migrate dev --name init
```

4. Jalankan server:
```
npm run start:dev
```

## Endpoints
- GET/POST/PUT/DELETE /books
- GET/POST/PUT/DELETE /categories
- GET/POST/PUT/DELETE /users
- GET/POST/PUT/DELETE /loans