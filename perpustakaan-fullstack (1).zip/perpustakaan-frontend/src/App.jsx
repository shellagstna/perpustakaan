
import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [books, setBooks] = useState([]);
  const [judul, setJudul] = useState('');
  const [penulis, setPenulis] = useState('');
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = () => {
    fetch('http://localhost:3000/book')
      .then(res => res.json())
      .then(data => setBooks(data));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = { title: judul, author: penulis };

    if (editingId) {
      fetch(`http://localhost:3000/book/${editingId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      }).then(() => {
        setEditingId(null);
        setJudul('');
        setPenulis('');
        fetchBooks();
      });
    } else {
      fetch('http://localhost:3000/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      }).then(() => {
        setJudul('');
        setPenulis('');
        fetchBooks();
      });
    }
  };

  const handleDelete = (id) => {
    fetch(`http://localhost:3000/book/${id}`, { method: 'DELETE' })
      .then(() => fetchBooks());
  };

  const handleEdit = (book) => {
    setJudul(book.title);
    setPenulis(book.author);
    setEditingId(book.id);
  };

  const filteredBooks = books.filter(b => 
    b.title.toLowerCase().includes(search.toLowerCase()) || 
    b.author.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container py-5">
      <h2 className="mb-4">📚 Perpustakaan</h2>
      <form onSubmit={handleSubmit} className="mb-4">
        <div className="row g-2">
          <div className="col-md">
            <input type="text" className="form-control" placeholder="Judul" value={judul} onChange={(e) => setJudul(e.target.value)} required />
          </div>
          <div className="col-md">
            <input type="text" className="form-control" placeholder="Penulis" value={penulis} onChange={(e) => setPenulis(e.target.value)} required />
          </div>
          <div className="col-md-auto">
            <button className="btn btn-primary" type="submit">{editingId ? "Update" : "Tambah"}</button>
          </div>
        </div>
      </form>

      <input type="text" className="form-control mb-3" placeholder="Cari buku..." value={search} onChange={(e) => setSearch(e.target.value)} />

      <ul className="list-group">
        {filteredBooks.map(buku => (
          <li key={buku.id} className="list-group-item d-flex justify-content-between align-items-center">
            <span><strong>{buku.title}</strong> - {buku.author}</span>
            <div>
              <button className="btn btn-sm btn-warning me-2" onClick={() => handleEdit(buku)}>Edit</button>
              <button className="btn btn-sm btn-danger" onClick={() => handleDelete(buku.id)}>Hapus</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
